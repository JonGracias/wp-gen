<?php
define('DB_NAME', 'html');
define('DB_USER', 'Admin');
define('DB_PASSWORD', 'password');
define('DB_HOST', 'localhost');
define('WP_CONTENT_DIR', '/var/lib/projects/html/wp-content');
define('WP_DEFAULT_THEME', 'twentytwentyfour');
define('WP_AUTO_UPDATE_CORE', true);
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);

// Site setup configuration
define('WP_TITLE', 'Datakiin.Dev');
define('WP_ADMIN_USER', 'jon.gracias');
define('WP_ADMIN_PASSWORD', 'password');
define('WP_ADMIN_EMAIL', 'jon.gracias@gmail.com');
define('WP_SEARCH_ENGINE_VISIBILITY', false);
?>
